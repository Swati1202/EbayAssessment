package PageObject;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AddProduct {

	WebDriver driver;

	public AddProduct(WebDriver rDriver)
	{
		driver=rDriver;

		PageFactory.initElements(rDriver, this);
	}	
	
	@FindBy(id = "//div[@id='gh-ac-box2']/input[@placeholder='Search for anything']")
	WebElement searchBook;
	
	@FindBy(id="//input[@id='gh-btn']")
	WebElement clickOnSearchBuuton;

	public void searchBook(String searchProductName)
	{
		searchBook.sendKeys(searchProductName);
	}
	
	public void clickOnSearchButton()
	{
		clickOnSearchBuuton.click();		
	}
	
	public void clickonProduct()
	{
		List<WebElement> web=driver.findElements(By.xpath("//div[@class='s-item__info clearfix']//div[@class='s-item__title']/span"));
		for(int i=1;i<web.size();i++) {
		if(i==2) {
		web.get(i).click();
          String mainWindowHandle = driver.getWindowHandle();
          Set<String> windowHandles = driver.getWindowHandles();
          Iterator<String> iterator = windowHandles.iterator();
          while (iterator.hasNext()) {
              String ChildWindow = iterator.next();
    		
                  if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
                  driver.switchTo().window(ChildWindow);
                  WebElement addToCart=driver.findElement(By.xpath("//span[@class='ux-call-to-action__cell']/span[contains(text(),'Add to cart')]"));
                  JavascriptExecutor js = (JavascriptExecutor) driver;
         		  js.executeScript("arguments[0].scrollIntoView();", addToCart);
        		  addToCart.click();

                  }     }
      }}
	}
	public void ValidateProductGotAdded()
	{
		String cardNumber=driver.findElement(By.xpath("//*[@id='gh-cart-n']")).getText();
		int product=Integer.parseInt(cardNumber);
		Assert.assertEquals(product, 1,"number is not equal");
		System.out.println("Executed successfully");
	}
	
	
	
	
	
}
