package StepDefinition;

import org.openqa.selenium.WebDriver;

import PageObject.AddProduct;
import Utitlities.ReadConfig;

import org.apache.logging.log4j.*;

/*Parent Class*/
public class BaseClass {
	public static  WebDriver driver;
	public AddProduct addProduct;
	public static Logger log;
	public ReadConfig readConfig;
}
