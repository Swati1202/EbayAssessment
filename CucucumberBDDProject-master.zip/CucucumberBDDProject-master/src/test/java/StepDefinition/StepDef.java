package StepDefinition;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import PageObject.AddProduct;
import Utitlities.ReadConfig;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

/*Child class of Baseclass*/
public class StepDef extends BaseClass {

	@Before
	public void setup1()
	{
		//object creation of readconfig
		readConfig = new ReadConfig();
		
		//initialise logger
		log = LogManager.getLogger("StepDef");

		System.out.println("Setup-Sanity method executed..");

		String browser = readConfig.getBrowser();
		
		//launch browser
		switch(browser.toLowerCase())
		{
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;

		case "msedge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;

		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		default:
			driver = null;
			break;

		}

		log.fatal("Setup1 executed...");

	}

	@Given("User Launch Chrome browser")
	public void user_launch_chrome_browser() {

		addProduct= new AddProduct(driver);
		log.info("chrome browser launched");
	}

	@When("User opens URL {string}")
	public void user_opens_url(String url) {
		driver.get(url);
		log.info("url opened");

	}
		
	@When("Search for {string}")
	public void searchBook(String book) {
		addProduct.searchBook(book);
		log.info("Search for Book");

	}
	
	@When("Click on the first book in the list")
	public void clickOnTheFirstSearchedProduct() {
		addProduct.clickOnSearchButton();
		log.info("List of Books displayed");
	}
	
	@When("In the item listing page click on Add to cart")
	public void clickOnSearchButton() {
		addProduct.clickonProduct();
		log.info("");
	}
	
	@Then("Validate the cart has been updated and displays the number of items in the cart as shown below in yellow")
	public void validateCradGotAdded() {

		addProduct.ValidateProductGotAdded();

	}
	
	@After
    public void tearDown() {
        // Quit the driver after each scenario
        if (driver != null) {
            driver.quit();
        }
    }

	@AfterStep
	public void addScreenshot(Scenario scenario){

		if(scenario.isFailed())
		{
		final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		//attach image file report(data, media type, name of the attachment)
		scenario.attach(screenshot, "image/png", scenario.getName());
		}
	}


}
