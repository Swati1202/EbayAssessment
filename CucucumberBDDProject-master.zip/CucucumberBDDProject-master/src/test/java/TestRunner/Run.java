package TestRunner;


import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
@CucumberOptions(
		
		features = {"./Features/AddProduct.feature"},
		glue="StepDefinition",
		dryRun = false,
		monochrome = true,
		tags = "@Regression",//scenarios under @sanity tag will be executed
		plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}

		)
public class Run extends AbstractTestNGCucumberTests{
}
