import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckCheckboxChecked {

	public static void main(String[] args) {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\anand\\Documents\\chromedriver.exe"); 		
      WebDriver driver = new ChromeDriver();	
      driver.get("https://omayo.blogspot.com/");
     WebElement ele=  driver.findElement(By.xpath("//input[@id='checkbox2']"));  
     if(ele.isSelected())
     {
    	 System.out.println("Element is checked");
     }
     else
     {
    	 System.out.println("Element is not checked ");
    	 ele.click();
    	 System.out.println("Element is checked now");
    	 
     }
     driver.quit();
	}

}
