import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ColumnDataFetching {

	public static void main(String[] args) {

		 System.setProperty("webdriver.chrome.driver","C:\\Users\\anand\\Documents\\chromedriver.exe"); 		
	     WebDriver driver = new ChromeDriver();	
	     driver.get("https://www.iplt20.com/points-table/men/2024");
	     driver.manage().window().maximize();
	     List<WebElement> teamName= driver.findElements(By.xpath("//tbody[@id='pointsdata']//tr/td[11]"));
	     int rowSize= teamName.size();
	     for(int i=1;i<=rowSize;i++)
	     {
	    	 WebElement ele= driver.findElement(By.xpath("//tbody[@id='pointsdata']//tr["+i+"]/td[11]"));
	    	 String str=ele.getText();
	    	 for(int j=i+1;j<=rowSize;j++)
	    	 {	    	
	         WebElement checkPoints= driver.findElement(By.xpath("//tbody[@id='pointsdata']//tr["+j+"]/td[11]"));
	         String check=checkPoints.getText();
	         if(str.equals(check)) {
		     WebElement teamName1= driver.findElement(By.xpath("//tbody[@id='pointsdata']//tr["+i+"]/td[3]"));
	    	 String str1=teamName1.getText();
	         WebElement checkPoints1= driver.findElement(By.xpath("//tbody[@id='pointsdata']//tr["+j+"]/td[3]"));
	    	 String str2=checkPoints1.getText();
	         System.out.println(str1+ " , "+str2+"="+str );
        	}
	    	 }
				/*
				 * WebElement teamName2=
				 * driver.findElement(By.xpath("//tbody[@id='pointsdata']//tr["+i+"]/td[3]"));
				 * String str2=teamName2.getText(); System.out.println(str2+" = "+str);
				 */
	    	 } 
	     driver.quit();
	         
	  }	      
}
