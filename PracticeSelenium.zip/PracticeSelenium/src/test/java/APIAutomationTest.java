
public class APIAutomationTest {
	
	@Test(priority=1)
	POJOClass data= new POJOClass();
	data

}
