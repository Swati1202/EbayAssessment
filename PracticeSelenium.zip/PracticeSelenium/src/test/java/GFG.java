import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;

public class GFG {

	    public static void main(String[] args) 
	    { 
	  
	        // create a list 
	        List<WebElement> lt = new ArrayList<WebElement>(); 
	  
	        // add the member of list 
	        lt.add(new WebElement(1, "Geeks")); 
	        lt.add(new WebElement(2, "For")); 
	        lt.add(new WebElement(3, "Geeks")); 
	  
	        // create map with the help of 
	        // Object (stu) method 
	        // create object of Map class 
	        Map<Integer, String> map = new HashMap<>(); 
	  
	        // put every value list to Map 
	        for (Student stu : lt) { 
	            map.put(stu.getId(), stu.getName()); 
	        } 
	  
	        // print map 
	        System.out.println("Map  : " + map); 
	        
	    } 

	}

