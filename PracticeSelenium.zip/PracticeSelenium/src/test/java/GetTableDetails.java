import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTableDetails {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\anand\\Documents\\chromedriver.exe"); 		
	      WebDriver driver = new ChromeDriver();	
	      driver.get("https://omayo.blogspot.com/");
	      driver.manage().window().maximize();
	    //  int rowSize=driver.findElements(By.xpath("//table[@id='table1']//tbody//tr")).size();
	   //   System.out.println(rowSize);
	    //for(int i=1;i<=rowSize;i++)
	   // {	
	 //   WebElement headerName=  driver.findElement(By.xpath("//table[@id='table1']//tbody//tr["+i+"]//td[3]"));    
	 //   String columnValue=headerName.getText();
    	//System.out.println(columnValue);	    
		/*
		 * List<WebElement> points=
		 * driver.findElements(By.xpath("//table[@id='table1']//td[3]")); for(int
		 * i=0;i<points.size();i++) { System.out.println(points.get(i).getText());
		 * 
		 * }
		 */
		   int rowSize=driver.findElements(By.xpath("//table[@id='table1']//tbody//tr")).size();
	       for (int i = 1; i <= rowSize; i++) {
	    	   WebElement ageColumn = driver.findElement(By.xpath("//table[@id='table1']//tbody//tr["+i+"]//td[3]"));
	    	   if (ageColumn.getText().equalsIgnoreCase("Delhi")) {
	    		   String columnValue=ageColumn.getText();
	    	    System.out.println(columnValue);
	    	   }
	    	  }
	   driver.quit();
	    }

     }

