package scenarioBasedQuestion;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ScenariosBrowserQuestions {
	public static void main(String[] args) {	
		 WebDriverManager.chromedriver().setup();
			WebDriver driver = new ChromeDriver();
	       driver.get("https://ebay.com");
	       driver.manage().window().maximize();
	    driver.findElement(By.xpath("//div[@id='gh-ac-box2']/input[@placeholder='Search for anything']")).sendKeys("Book");
		driver.findElement(By.xpath("//input[@id='gh-btn']")).click();
		List<WebElement> web=driver.findElements(By.xpath("//div[@class='s-item__info clearfix']//div[@class='s-item__title']/span"));
		for(int i=1;i<web.size();i++) {
		if(i==2) {
		web.get(i).click();
          String mainWindowHandle = driver.getWindowHandle();
          Set<String> windowHandles = driver.getWindowHandles();
          Iterator<String> iterator = windowHandles.iterator();
          while (iterator.hasNext()) {
              String ChildWindow = iterator.next();
    		
                  if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
                  driver.switchTo().window(ChildWindow);
                  WebElement addToCart=driver.findElement(By.xpath("//span[@class='ux-call-to-action__cell']/span[contains(text(),'Add to cart')]"));
                  JavascriptExecutor js = (JavascriptExecutor) driver;
         		  js.executeScript("arguments[0].scrollIntoView();", addToCart);
        		  addToCart.click();
        		String cardNumber=driver.findElement(By.xpath("//*[@id='gh-cart-n']")).getText();
        		int product=Integer.parseInt(cardNumber);
        		Assert.assertEquals(product, 1,"number is not equal");
        		System.out.println("Executed successfully");
        		driver.close();
                  }                  
          }
}}}}

